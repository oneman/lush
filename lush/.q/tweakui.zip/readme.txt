To install, right-click on tweakui.inf and select INSTALL.

